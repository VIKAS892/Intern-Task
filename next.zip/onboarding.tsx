"use client"

import { useState } from "react"
import { WelcomeStep } from "./components/welcome-step"
import { UserInfoStep } from "./components/user-info-step"
import { PreferencesStep } from "./components/preferences-step"
import { CompletionStep } from "./components/completion-step"
import { ProgressIndicator } from "./components/progress-indicator"
import type { UserData, Preferences } from "./types/onboarding"
// import { ThemeProvider } from "./components/theme-provider"

const steps = [
  { title: "Welcome", description: "Get started" },
  { title: "Profile", description: "Your info" },
  { title: "Preferences", description: "Customize" },
  { title: "Complete", description: "All done" },
]

export default function Onboarding() {
  const [currentStep, setCurrentStep] = useState(0)
  const [userData, setUserData] = useState<UserData>({
    firstName: "",
    lastName: "",
    email: "",
    company: "",
    role: "",
  })
  const [preferences, setPreferences] = useState<Preferences>({
    notifications: true,
    newsletter: false,
    theme: "system",
    language: "en",
  })

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleComplete = () => {
    // Redirect to dashboard
    window.location.href = "/dashboard"
  }

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return <WelcomeStep onNext={nextStep} />
      case 1:
        return <UserInfoStep userData={userData} onUpdate={setUserData} onNext={nextStep} onBack={prevStep} />
      case 2:
        return (
          <PreferencesStep preferences={preferences} onUpdate={setPreferences} onNext={nextStep} onBack={prevStep} />
        )
      case 3:
        return <CompletionStep userData={userData} preferences={preferences} onComplete={handleComplete} />
      default:
        return <WelcomeStep onNext={nextStep} />
    }
  }

  return (
    // <ThemeProvider defaultTheme="system" storageKey="ui-theme">
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {currentStep > 0 && <ProgressIndicator currentStep={currentStep} totalSteps={steps.length} steps={steps} />}
        <div className="bg-white rounded-lg shadow-lg p-8">{renderStep()}</div>
      </div>
    </div>
    // </ThemeProvider>
  )
}
