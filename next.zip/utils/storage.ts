import type { UserData, Preferences } from "../types/onboarding"

export interface DashboardData {
  teamMembers: number
  activeProjects: number
  notifications: number
  weeklyProgress: Array<{
    day: string
    tasks: number
    completed: number
    value: number
  }>
  projects: Array<{
    id: string
    name: string
    status: "active" | "completed" | "pending"
    dueDate: string
    progress: number
  }>
  teamMembersList: Array<{
    id: string
    name: string
    email: string
    role: string
    avatar?: string
    status: "active" | "inactive"
  }>
  notificationsList: Array<{
    id: string
    title: string
    message: string
    type: "info" | "warning" | "success" | "error"
    read: boolean
    timestamp: string
  }>
}

// Dummy API simulation
class DummyAPI {
  private delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

  async saveUserData(userData: UserData, preferences: Preferences): Promise<{ success: boolean; message: string }> {
    await this.delay(500) // Simulate network delay

    try {
      localStorage.setItem("onboarding-user-data", JSON.stringify(userData))
      localStorage.setItem("onboarding-preferences", JSON.stringify(preferences))
      localStorage.setItem("onboarding-completed", "true")
      localStorage.setItem(
        "user-session",
        JSON.stringify({
          userId: `user_${Date.now()}`,
          loginTime: new Date().toISOString(),
          lastActivity: new Date().toISOString(),
        }),
      )

      return { success: true, message: "User data saved successfully" }
    } catch (error) {
      return { success: false, message: "Failed to save user data" }
    }
  }

  async getUserData(): Promise<UserData | null> {
    await this.delay(200)

    if (typeof window !== "undefined") {
      const data = localStorage.getItem("onboarding-user-data")
      return data ? JSON.parse(data) : null
    }
    return null
  }

  async getPreferences(): Promise<Preferences | null> {
    await this.delay(200)

    if (typeof window !== "undefined") {
      const data = localStorage.getItem("onboarding-preferences")
      return data ? JSON.parse(data) : null
    }
    return null
  }

  async getDashboardData(): Promise<DashboardData> {
    await this.delay(300)

    const defaultData: DashboardData = {
      teamMembers: 24,
      activeProjects: 12,
      notifications: 7,
      weeklyProgress: [
        { day: "Mon", tasks: 12, completed: 8, value: 70 },
        { day: "Tue", tasks: 15, completed: 12, value: 78 },
        { day: "Wed", tasks: 10, completed: 9, value: 85 },
        { day: "Thu", tasks: 18, completed: 14, value: 75 },
        { day: "Fri", tasks: 14, completed: 11, value: 92 },
        { day: "Sat", tasks: 8, completed: 6, value: 95 },
        { day: "Sun", tasks: 5, completed: 4, value: 88 },
      ],
      projects: [
        {
          id: "proj_1",
          name: "Website Redesign",
          status: "active",
          dueDate: "2024-01-15",
          progress: 75,
        },
        {
          id: "proj_2",
          name: "Mobile App Development",
          status: "active",
          dueDate: "2024-01-20",
          progress: 45,
        },
        {
          id: "proj_3",
          name: "Database Migration",
          status: "pending",
          dueDate: "2024-01-25",
          progress: 20,
        },
      ],
      teamMembersList: [
        {
          id: "member_1",
          name: "John Doe",
          email: "john@company.com",
          role: "Developer",
          status: "active",
        },
        {
          id: "member_2",
          name: "Jane Smith",
          email: "jane@company.com",
          role: "Designer",
          status: "active",
        },
        {
          id: "member_3",
          name: "Mike Johnson",
          email: "mike@company.com",
          role: "Manager",
          status: "active",
        },
      ],
      notificationsList: [
        {
          id: "notif_1",
          title: "Project Update",
          message: "Website redesign is 75% complete",
          type: "info",
          read: false,
          timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutes ago
        },
        {
          id: "notif_2",
          title: "New Team Member",
          message: "Sarah Wilson joined the team",
          type: "success",
          read: false,
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
        },
        {
          id: "notif_3",
          title: "Deadline Reminder",
          message: "Mobile app development due in 3 days",
          type: "warning",
          read: true,
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
        },
      ],
    }

    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("dashboard-data")
      if (stored) {
        return JSON.parse(stored)
      } else {
        localStorage.setItem("dashboard-data", JSON.stringify(defaultData))
      }
    }

    return defaultData
  }

  async updateDashboardData(data: Partial<DashboardData>): Promise<{ success: boolean; message: string }> {
    await this.delay(400)

    try {
      if (typeof window !== "undefined") {
        const currentData = await this.getDashboardData()
        const updatedData = { ...currentData, ...data }
        localStorage.setItem("dashboard-data", JSON.stringify(updatedData))
      }
      return { success: true, message: "Dashboard data updated successfully" }
    } catch (error) {
      return { success: false, message: "Failed to update dashboard data" }
    }
  }

  async markNotificationAsRead(notificationId: string): Promise<{ success: boolean; message: string }> {
    await this.delay(200)

    try {
      const dashboardData = await this.getDashboardData()
      const updatedNotifications = dashboardData.notificationsList.map((notif) =>
        notif.id === notificationId ? { ...notif, read: true } : notif,
      )

      await this.updateDashboardData({
        notificationsList: updatedNotifications,
        notifications: updatedNotifications.filter((n) => !n.read).length,
      })

      return { success: true, message: "Notification marked as read" }
    } catch (error) {
      return { success: false, message: "Failed to update notification" }
    }
  }

  async addProject(
    project: Omit<DashboardData["projects"][0], "id">,
  ): Promise<{ success: boolean; message: string; projectId?: string }> {
    await this.delay(500)

    try {
      const dashboardData = await this.getDashboardData()
      const newProject = {
        ...project,
        id: `proj_${Date.now()}`,
      }

      const updatedProjects = [...dashboardData.projects, newProject]
      await this.updateDashboardData({
        projects: updatedProjects,
        activeProjects: updatedProjects.filter((p) => p.status === "active").length,
      })

      return { success: true, message: "Project created successfully", projectId: newProject.id }
    } catch (error) {
      return { success: false, message: "Failed to create project" }
    }
  }

  async addTeamMember(
    member: Omit<DashboardData["teamMembersList"][0], "id">,
  ): Promise<{ success: boolean; message: string; memberId?: string }> {
    await this.delay(500)

    try {
      const dashboardData = await this.getDashboardData()
      const newMember = {
        ...member,
        id: `member_${Date.now()}`,
      }

      const updatedMembers = [...dashboardData.teamMembersList, newMember]
      await this.updateDashboardData({
        teamMembersList: updatedMembers,
        teamMembers: updatedMembers.filter((m) => m.status === "active").length,
      })

      return { success: true, message: "Team member added successfully", memberId: newMember.id }
    } catch (error) {
      return { success: false, message: "Failed to add team member" }
    }
  }
}

// Create API instance
export const api = new DummyAPI()

// Legacy functions for backward compatibility
export const saveUserData = async (userData: UserData, preferences: Preferences) => {
  return await api.saveUserData(userData, preferences)
}

export const getUserData = async (): Promise<UserData | null> => {
  return await api.getUserData()
}

export const getPreferences = async (): Promise<Preferences | null> => {
  return await api.getPreferences()
}

export const isOnboardingCompleted = (): boolean => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("onboarding-completed") === "true"
  }
  return false
}

export const getDashboardData = async (): Promise<DashboardData> => {
  return await api.getDashboardData()
}

// Session management
export const getUserSession = () => {
  if (typeof window !== "undefined") {
    const session = localStorage.getItem("user-session")
    return session ? JSON.parse(session) : null
  }
  return null
}

export const updateLastActivity = () => {
  if (typeof window !== "undefined") {
    const session = getUserSession()
    if (session) {
      session.lastActivity = new Date().toISOString()
      localStorage.setItem("user-session", JSON.stringify(session))
    }
  }
}

export const clearUserData = () => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("onboarding-user-data")
    localStorage.removeItem("onboarding-preferences")
    localStorage.removeItem("onboarding-completed")
    localStorage.removeItem("dashboard-data")
    localStorage.removeItem("user-session")
  }
}
