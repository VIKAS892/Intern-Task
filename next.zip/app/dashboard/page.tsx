"use client"

import { DashboardNew } from "../../components/dashboard-new"

export default function DashboardPage() {
  return <DashboardNew />
}
