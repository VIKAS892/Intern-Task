import Onboarding from "../onboarding"

export default function Page() {
  return <Onboarding />
}
