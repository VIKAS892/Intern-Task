"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, ArrowRight, Book, Users, Settings, Loader2 } from "lucide-react"
import type { UserData, Preferences } from "../types/onboarding"
import { api } from "../utils/storage"

interface CompletionStepProps {
  userData: UserData
  preferences: Preferences
  onComplete: () => void
}

export function CompletionStep({ userData, preferences, onComplete }: CompletionStepProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [saveStatus, setSaveStatus] = useState<{ success?: boolean; message?: string } | null>(null)

  const handleComplete = async () => {
    setIsLoading(true)
    setSaveStatus(null)

    try {
      // Save data using the dummy API
      const result = await api.saveUserData(userData, preferences)
      setSaveStatus(result)

      if (result.success) {
        // Show success message briefly before redirecting
        setTimeout(() => {
          onComplete()
        }, 1500)
      }
    } catch (error) {
      setSaveStatus({ success: false, message: "An unexpected error occurred" })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
          <CheckCircle className="w-8 h-8 text-green-600" />
        </div>
        <div>
          <h2 className="text-3xl font-bold">Welcome aboard, {userData.firstName}!</h2>
          <p className="text-muted-foreground text-lg mt-2">Your account is all set up and ready to go</p>
        </div>
      </div>

      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle className="text-lg">Account Summary</CardTitle>
          <CardDescription>Here's what we've set up for you</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Name:</span>
            <span>
              {userData.firstName} {userData.lastName}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Email:</span>
            <span>{userData.email}</span>
          </div>
          {userData.company && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Company:</span>
              <span>{userData.company}</span>
            </div>
          )}
          {userData.role && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Role:</span>
              <span className="capitalize">{userData.role}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Language:</span>
            <span className="capitalize">{preferences.language}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Notifications:</span>
            <span>{preferences.notifications ? "Enabled" : "Disabled"}</span>
          </div>
        </CardContent>
      </Card>

      {/* Save Status */}
      {saveStatus && (
        <Card
          className={`max-w-md mx-auto ${saveStatus.success ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}`}
        >
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              {saveStatus.success ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <div className="h-5 w-5 rounded-full bg-red-600" />
              )}
              <span className={`text-sm font-medium ${saveStatus.success ? "text-green-800" : "text-red-800"}`}>
                {saveStatus.message}
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-3 gap-4 max-w-2xl mx-auto">
        <Card className="text-center">
          <CardHeader>
            <Book className="w-8 h-8 mx-auto text-primary" />
            <CardTitle className="text-lg">Documentation</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>Learn how to make the most of our platform</CardDescription>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <Users className="w-8 h-8 mx-auto text-primary" />
            <CardTitle className="text-lg">Community</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>Connect with other users and get support</CardDescription>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <Settings className="w-8 h-8 mx-auto text-primary" />
            <CardTitle className="text-lg">Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>Customize your account anytime</CardDescription>
          </CardContent>
        </Card>
      </div>

      <div className="text-center">
        <Button onClick={handleComplete} size="lg" className="px-8" disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving Data...
            </>
          ) : (
            <>
              Enter Dashboard
              <ArrowRight className="w-4 h-4 ml-2" />
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
