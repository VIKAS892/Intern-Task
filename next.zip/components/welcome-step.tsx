"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Rocket, Users, Zap } from "lucide-react"

interface WelcomeStepProps {
  onNext: () => void
}

export function WelcomeStep({ onNext }: WelcomeStepProps) {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
          <Rocket className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-bold">Welcome to Our Platform!</h1>
          <p className="text-muted-foreground text-lg mt-2">Let's get you set up in just a few quick steps</p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <Card className="text-center">
          <CardHeader>
            <Users className="w-8 h-8 mx-auto text-primary" />
            <CardTitle className="text-lg">Connect</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>Build meaningful connections with your team and community</CardDescription>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <Zap className="w-8 h-8 mx-auto text-primary" />
            <CardTitle className="text-lg">Accelerate</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>Boost your productivity with powerful tools and automation</CardDescription>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <Rocket className="w-8 h-8 mx-auto text-primary" />
            <CardTitle className="text-lg">Launch</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>Turn your ideas into reality with our comprehensive platform</CardDescription>
          </CardContent>
        </Card>
      </div>

      <div className="text-center">
        <Button onClick={onNext} size="lg" className="px-8">
          Get Started
        </Button>
      </div>
    </div>
  )
}
