"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Bell, Mail, Globe } from "lucide-react"
import type { Preferences } from "../types/onboarding"

interface PreferencesStepProps {
  preferences: Preferences
  onUpdate: (preferences: Preferences) => void
  onNext: () => void
  onBack: () => void
}

export function PreferencesStep({ preferences, onUpdate, onNext, onBack }: PreferencesStepProps) {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold">Customize your experience</h2>
        <p className="text-muted-foreground">Set your preferences to make the platform work for you</p>
      </div>

      <div className="max-w-2xl mx-auto space-y-4">
        <Card>
          <CardHeader className="flex flex-row items-center space-y-0 pb-2">
            <Bell className="w-5 h-5 mr-2" />
            <div>
              <CardTitle className="text-lg">Notifications</CardTitle>
              <CardDescription>Manage how you receive updates and alerts</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="notifications" className="flex flex-col space-y-1">
                <span>Push Notifications</span>
                <span className="text-sm text-muted-foreground">Get notified about important updates</span>
              </Label>
              <Switch
                id="notifications"
                checked={preferences.notifications}
                onCheckedChange={(checked) => onUpdate({ ...preferences, notifications: checked })}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center space-y-0 pb-2">
            <Mail className="w-5 h-5 mr-2" />
            <div>
              <CardTitle className="text-lg">Email Preferences</CardTitle>
              <CardDescription>Choose what emails you'd like to receive</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Label htmlFor="newsletter" className="flex flex-col space-y-1">
                <span>Newsletter</span>
                <span className="text-sm text-muted-foreground">Weekly updates and tips</span>
              </Label>
              <Switch
                id="newsletter"
                checked={preferences.newsletter}
                onCheckedChange={(checked) => onUpdate({ ...preferences, newsletter: checked })}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center space-y-0 pb-2">
            <Globe className="w-5 h-5 mr-2" />
            <div>
              <CardTitle className="text-lg">Language</CardTitle>
              <CardDescription>Select your preferred language</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label>Language</Label>
              <Select
                value={preferences.language}
                onValueChange={(value) => onUpdate({ ...preferences, language: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="de">Deutsch</SelectItem>
                  <SelectItem value="zh">中文</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-3 max-w-md mx-auto">
        <Button variant="outline" onClick={onBack} className="flex-1">
          Back
        </Button>
        <Button onClick={onNext} className="flex-1">
          Continue
        </Button>
      </div>
    </div>
  )
}
