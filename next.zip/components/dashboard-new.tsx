"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Users, FolderOpen, Bell, Plus, UserPlus, BarChart3, Settings, Sun, Moon, Loader2 } from "lucide-react"
import { api, isOnboardingCompleted, updateLastActivity, clearUserData } from "../utils/storage"
import type { DashboardData } from "../utils/storage"
import { UserData } from "@/types/onboarding"
export function DashboardNew() {
  const router = useRouter()
  const [userData, setUserData] = useState<UserData | null>(null)
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [theme, setTheme] = useState<"light" | "dark">("light")

  useEffect(() => {
    loadDashboardData()

    // Update last activity every 5 minutes
    const activityInterval = setInterval(updateLastActivity, 5 * 60 * 1000)

    return () => clearInterval(activityInterval)
  }, [])

  const loadDashboardData = async () => {
    try {
      // Check if we're in the browser environment
      if (typeof window === "undefined") return

      if (!isOnboardingCompleted()) {
        router.push("/")
        return
      }

      // Load user data and dashboard data concurrently
      const [user, dashboard] = await Promise.all([api.getUserData(), api.getDashboardData()])

      if (!user) {
        router.push("/")
        return
      }

      setUserData(user)
      setDashboardData(dashboard)
      updateLastActivity()
    } catch (error) {
      console.error("Failed to load dashboard data:", error)
      // Handle error - maybe show a toast or error message
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    // Apply theme - only in browser
    if (typeof window === "undefined") return

    const root = document.documentElement
    root.classList.remove("light", "dark")
    root.classList.add(theme)
  }, [theme])

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  }

  const handleLogout = () => {
    clearUserData()
    router.push("/")
  }

  const handleCreateProject = async () => {
    if (!dashboardData) return

    try {
      const result = await api.addProject({
        name: `New Project ${dashboardData.projects.length + 1}`,
        status: "active",
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 7 days from now
        progress: 0,
      })

      if (result.success) {
        // Reload dashboard data to reflect changes
        const updatedDashboard = await api.getDashboardData()
        setDashboardData(updatedDashboard)
      }
    } catch (error) {
      console.error("Failed to create project:", error)
    }
  }

  const handleInviteTeamMember = async () => {
    if (!dashboardData) return

    try {
      const result = await api.addTeamMember({
        name: "New Team Member",
        email: "newmember@company.com",
        role: "Developer",
        status: "active",
      })

      if (result.success) {
        // Reload dashboard data to reflect changes
        const updatedDashboard = await api.getDashboardData()
        setDashboardData(updatedDashboard)
      }
    } catch (error) {
      console.error("Failed to invite team member:", error)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-blue-500 mx-auto" />
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!userData || !dashboardData) return null

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${theme === "dark" ? "dark bg-gray-900" : "bg-gray-50"}`}
    >
      {/* Header */}
      <header
        className={`${theme === "dark" ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} border-b transition-colors duration-300`}
      >
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className={`text-2xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}>
                Welcome back, {userData.firstName}!
              </h1>
              <p className={`text-sm ${theme === "dark" ? "text-gray-400" : "text-gray-600"}`}>Dashboard, {userData.company}</p>
            </div>
            <div className="flex items-center space-x-3">
              <span className={`text-sm ${theme === "dark" ? "text-gray-400" : "text-gray-600"}`}>
                {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </span>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                    <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setTheme("light")}>
                    <Sun className="mr-2 h-4 w-4" />
                    Light
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setTheme("dark")}>
                    <Moon className="mr-2 h-4 w-4" />
                    Dark
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Avatar className="cursor-pointer">
                    <AvatarFallback className="bg-blue-500 text-white text-sm font-medium">
                      {getInitials(userData.firstName, userData.lastName)}
                    </AvatarFallback>
                  </Avatar>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Stats Cards */}
          <div className="grid gap-6 md:grid-cols-3">
            {/* Team Members */}
            <Card
              className={`${theme === "dark" ? "bg-gray-800 border-gray-700" : "bg-white"} transition-colors duration-300`}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-sm font-medium ${theme === "dark" ? "text-gray-400" : "text-gray-600"}`}>
                      Team Members
                    </p>
                    <p className={`text-3xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}>
                      {dashboardData.teamMembers}
                    </p>
                    <p className="text-sm text-blue-600 font-medium">+2 this month</p>
                  </div>
                  <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Active Projects */}
            <Card
              className={`${theme === "dark" ? "bg-gray-800 border-gray-700" : "bg-white"} transition-colors duration-300`}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-sm font-medium ${theme === "dark" ? "text-gray-400" : "text-gray-600"}`}>
                      Active Projects
                    </p>
                    <p className={`text-3xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}>
                      {dashboardData.activeProjects}
                    </p>
                    <p className="text-sm text-green-600 font-medium">3 due this week</p>
                  </div>
                  <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
                    <FolderOpen className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Notifications */}
            <Card
              className={`${theme === "dark" ? "bg-gray-800 border-gray-700" : "bg-white"} transition-colors duration-300`}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-sm font-medium ${theme === "dark" ? "text-gray-400" : "text-gray-600"}`}>
                      Notifications
                    </p>
                    <p className={`text-3xl font-bold ${theme === "dark" ? "text-white" : "text-gray-900"}`}>
                      {dashboardData.notifications}
                    </p>
                    <p className="text-sm text-orange-600 font-medium">2 unread</p>
                  </div>
                  <div className="p-3 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
                    <Bell className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Weekly Progress Chart */}
          <Card
            className={`${theme === "dark" ? "bg-gray-800 border-gray-700" : "bg-white"} transition-colors duration-300`}
          >
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className={`text-lg font-semibold ${theme === "dark" ? "text-white" : "text-gray-900"}`}>
                    Weekly Progress
                  </h3>
                  <p className={`text-sm ${theme === "dark" ? "text-gray-400" : "text-gray-600"}`}>
                    Team productivity over the last 7 days
                  </p>
                </div>
                <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                  <BarChart3 className="h-5 w-5 text-green-600" />
                </div>
              </div>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={dashboardData.weeklyProgress}>
                    <XAxis
                      dataKey="day"
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12, fill: theme === "dark" ? "#9CA3AF" : "#6B7280" }}
                    />
                    <YAxis
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12, fill: theme === "dark" ? "#9CA3AF" : "#6B7280" }}
                      domain={[0, 100]}
                    />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#3B82F6"
                      strokeWidth={3}
                      dot={{ fill: "#3B82F6", strokeWidth: 2, r: 4 }}
                      activeDot={{ r: 6, stroke: "#3B82F6", strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Button className="h-16 bg-blue-600 hover:bg-blue-700 text-white font-medium" onClick={handleCreateProject}>
              <div className="flex flex-col items-center space-y-1">
                <Plus className="h-5 w-5" />
                <span className="text-sm">Start New Project</span>
                <span className="text-xs opacity-80">Create and manage</span>
              </div>
            </Button>

            <Button
              className="h-16 bg-green-600 hover:bg-green-700 text-white font-medium"
              onClick={handleInviteTeamMember}
            >
              <div className="flex flex-col items-center space-y-1">
                <UserPlus className="h-5 w-5" />
                <span className="text-sm">Invite Team Member</span>
                <span className="text-xs opacity-80">Add to workspace</span>
              </div>
            </Button>

            <Button className="h-16 bg-purple-600 hover:bg-purple-700 text-white font-medium">
              <div className="flex flex-col items-center space-y-1">
                <BarChart3 className="h-5 w-5" />
                <span className="text-sm">View Reports</span>
                <span className="text-xs opacity-80">Analytics & insights</span>
              </div>
            </Button>

            <Button className="h-16 bg-gray-600 hover:bg-gray-700 text-white font-medium">
              <div className="flex flex-col items-center space-y-1">
                <Settings className="h-5 w-5" />
                <span className="text-sm">Settings</span>
                <span className="text-xs opacity-80">Customize workspace</span>
              </div>
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
