import type React from "react"
export interface UserData {
  firstName: string
  lastName: string
  email: string
  company?: string
  role?: string
}

export interface Preferences {
  notifications: boolean
  newsletter: boolean
  language: string
}

export interface OnboardingStep {
  id: string
  title: string
  description: string
  component: React.ComponentType<any>
}
